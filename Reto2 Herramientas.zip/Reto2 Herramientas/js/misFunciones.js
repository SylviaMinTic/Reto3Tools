function traerInformacionC(){
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/client/client",
        type:"GET",
        datatype:"JSON",
        success:function(respuestaC){
            console.log(respuestaC);
            pintarRespuestaC(respuestaC.items);
        }

    });
    
}

function pintarRespuestaC(items){
    let myTable="<table>";
    for(i=0;i<items.length;i++){
        myTable+="<tr>";
        myTable+="<td>"+items[i].id+"</td";
        myTable+="<td>"+items[i].name+"</td";
        myTable+="<td>"+items[i].email+"</td";
        myTable+="<td>"+items[i].age+"</td";
        myTable+="<td> <button onclick='borrarElementoC("+items[i].id+")'>Borrar</button>";
        myTable+="</tr>";
    }
    myTable+="</table>";
    $("#resultadoCliente").append(myTable);

}

function guardarInformacionC(){
    let myData={
        id:$("#id_cliente").val(),
        name:$("#name_cliente").val(),
        email:$("#email").val(),
        age:$("#age").val(),
    };
    let dataToSend=JSON.stringify(myData);
    console.log(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/client/client",
        type:"POST",
        data:myData,
        datatype:"JSON",
        success:function(respuestaC){
            $("#resultadoCliente").empty();
            $("#id").val("");
            $("#name").val("");
            $("#email").val("");
            $("#age").val("");
            traerInformacionC();
            alert("se ha guardado el dato")
        }
    });
}

function editarInformacionC(){
    let myData={
        id:$("#id_cliente").val(),
        name:$("#name_cliente").val(),
        email:$("#email").val(),
        age:$("#age").val(),
    };
    console.log(myData)
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/client/client",
        type:"PUT",
        data:dataToSend,
        contentType:"application/JSON",
        datatype:"JSON",
        success:function(respuestaC){
            $("#resultadoCliente").empty();
            $("#id").val("");
            $("#name").val("");
            $("#email").val("");
            $("#age").val("");
            traerInformacionC();
            alert("se ha actualizado")
        }
    });
}

function borrarElementoC(idElemento){
    let myData={
        id:idElemento
    };
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/client/client",
        type:"DELETE",
        data:dataToSend,
        contentType:"application/JSON",
        datatype:"JSON",
        success:function(respuestaC){
            $("#resultadoCliente").empty();
            traerInformacionC();
            alert("se ha eliminado")
        }
    });
}

function traerInformacionM(){
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/message/message",
        type:"GET",
        datatype:"JSON",
        success:function(respuestaM){
            console.log(respuestaM);
            pintarRespuestaM(respuestaM.items);
        }

    });

}

function pintarRespuestaM(items){
    let myTable="<table>";
    for(i=0;i<items.length;i++){
        myTable+="<tr>";
        myTable+="<td>"+items[i].id+"</td";
        myTable+="<td>"+items[i].messagetext+"</td";
        myTable+="<td> <button onclick='borrarElementoM("+items[i].id+")'>Borrar</button>";
        myTable+="</tr>";
    }
    myTable+="</table>";
    $("#resultadoMensaje").append(myTable);

}

function guardarInformacionM(){
    let myData={
        id:$("#id_mensaje").val(),
        messagetext:$("#messagetext").val(),
    };
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/message/message",
        type:"POST",
        data:myData,
        datatype:"JSON",
        success:function(respuestaM){
            $("#resultadoMensaje").empty();
            $("#id").val("");
            $("#messagetext").val("");
            traerInformacionM();
            alert("se ha guardado el dato")
        }
    });
}

function editarInformacionM(){
    let myData={
        id:$("#id_mensaje").val(),
        messagetext:$("#messagetext").val(),
    };
    console.log(myData)
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/message/message",
        type:"PUT",
        data:dataToSend,
        contentType:"application/JSON",
        datatype:"JSON",
        success:function(respuestaM){
            $("#resultadoMensaje").empty();
            $("#id").val("");
            $("#messagetext").val("");
            traerInformacionM();
            alert("se ha actualizado")
        }
    });
}

function borrarElementoM(idElemento){
    let myData={
        id:idElemento
    };
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/message/message",
        type:"DELETE",
        data:dataToSend,
        contentType:"application/JSON",
        datatype:"JSON",
        success:function(respuestaM){
            $("#resultadoMensaje").empty();
            traerInformacionM();
            alert("se ha eliminado")
        }
    });
}

function traerInformacionN(){
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/tool/tool",
        type:"GET",
        datatype:"JSON",
        success:function(respuestaN){
            console.log(respuestaN);
            pintarRespuestaN(respuestaN.items);
        }

    });

}

function pintarRespuestaN(items){
    let myTable="<table>";
    for(i=0;i<items.length;i++){
        myTable+="<tr>";
        myTable+="<td>"+items[i].id+"</td";
        myTable+="<td>"+items[i].brand+"</td";
        myTable+="<td>"+items[i].model+"</td";
        myTable+="<td>"+items[i].category_id+"</td";
        myTable+="<td>"+items[i].name+"</td";
        myTable+="<td> <button onclick='borrarElementoN("+items[i].id+")'>Borrar</button>";
        myTable+="</tr>";
    }
    myTable+="</table>";
    $("#resultadoNube").append(myTable);

}

function guardarInformacionN(){
    let myData={
        id:$("#id_nube").val(),
        brand:$("#brand").val(),
        model:$("#model").val(),
        category_id:$("#category_id").val(),
        name:$("#name_nube").val(),
    };
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/tool/tool",
        type:"POST",
        data:myData,
        datatype:"JSON",
        success:function(respuestaN){
            $("#resultadoNube").empty();
            $("#id").val("");
            $("#brand").val("");
            $("#model").val("");
            $("#category_id").val("");
            $("#name").val("");
            traerInformacionN();
            alert("se ha guardado el dato")
        }
    });
}

function editarInformacionN(){
    let myData={
        id:$("#id_nube").val(),
        brand:$("#brand").val(),
        model:$("#model").val(),
        category_id:$("#category_id").val(),
        name:$("#name_nube").val(),
    };
    console.log(myData)
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/tool/tool",
        type:"PUT",
        data:dataToSend,
        contentType:"application/JSON",
        datatype:"JSON",
        success:function(respuestaN){
            $("#resultadoNube").empty();
            $("#id").val("");
            $("#brand").val("");
            $("#model").val("");
            $("#category_id").val("");
            $("#name").val("");
            traerInformacionN();
            alert("se ha actualizado")
        }
    });
}

function borrarElementoN(idElemento){
    let myData={
        id:idElemento
    };
    let dataToSend=JSON.stringify(myData);
    $.ajax({
        url:"https://g25c620e88ff620-cb7wfi78wrvyg47e.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/tool/tool",
        type:"DELETE",
        data:dataToSend,
        contentType:"application/JSON",
        datatype:"JSON",
        success:function(respuestaN){
            $("#resultadoNube").empty();
            traerInformacionN();
            alert("se ha eliminado")
        }
    });
}
